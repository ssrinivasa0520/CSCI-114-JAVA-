// creating class name Square
class Square{
  
    

	// declaration of variable
    private int length;
  
    // default constructor
    public Square(){
      
    }
  
    // parameterised constructor
    public Square(int length){
        this.length = length;
    }
  
    // accessor method for length
    public int getLength(){
        return this.length;
    }
  
    // mutator method for length
    public void setLength(int length){
        this.length = length;
    }
  
    // calculate area method
    public int getSquareArea(){
        return length*length;
    }
  
    // calculate perimeter method
    public int getSquarePerimeter(){
        return 4*length;
    }
  
}

//creating class name Square
class Square{

 // declaration of variable
 private int length;

 // default constructor
 public Square(){
   
 }

 // parameterised constructor
 public Square(int length){
     this.length = length;
 }

 // accessor method for length
 public int getLength(){
     return this.length;
 }

 // mutator method for length
 public void setLength(int length){
     this.length = length;
 }

 // calculate area method
 public int getSquareArea(){
     return length*length;
 }

 // calculate perimeter method
 public int getSquarePerimeter(){
     return 4*length;
 }

}
