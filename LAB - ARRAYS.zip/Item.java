class Item
{
   double price;
   boolean isPet;
   int quantity;
   Item(double price,boolean isPet,int quantity)
   {
       this.price=price;
       this.isPet=isPet;
       this.quantity=quantity;
   }
}