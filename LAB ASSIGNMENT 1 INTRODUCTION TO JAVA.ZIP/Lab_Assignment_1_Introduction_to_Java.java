
public class Lab_Assignment_1_Introduction_to_Java {

	public static void main(String[] args) {
		System.out.println("Hello, My Name is Shreyas");
		System.out.println("I have 9 years of programmimg experience");
		System.out.print("Hello, My Name is Shreyas");
		System.out.print(" I have 9 years of programmimg experience");

	}

}
