public class Test
{
   public static void main(String[] args) {
       Manager m = new Manager("Shreyas", 388383892,"IT");
       System.out.println(m);
   }
}