class Executive extends Manager{

   public Executive(String aName, double aSalary, String aDepartment) {
       super(aName, aSalary, aDepartment);
       // TODO Auto-generated constructor stub
   }

   public String toString() {
       return super.toString();
      
   }

   public int hashCode() {
       return super.hashCode();
   }

   public boolean equals(Object obj) {
       return super.equals(obj);
   }
  
}